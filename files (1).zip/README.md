#

#Firstly download and make an npm install for SWE642-Frontend Angular. - VS code is preferred as IDE

#For backend download and make sure it runs on port 8080 - Intellij is preferred as IDE
#After making necessary configurations The app runs at localhost:4200 in the machine
#Look after Mysql commandclient for the database and install JDBC driver if not pre installed.
#













To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
# SWE642-FrontendAngular
